# Instructions

> Disclaimer: this software is not stable yet

## How to install 
clone the repo, then run `pip install .` in the working directory 
